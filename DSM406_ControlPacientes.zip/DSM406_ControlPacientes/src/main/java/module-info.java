module org.utl.dsm.dsm406_controlpacientes {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires unirest.java;


    opens org.utl.dsm.dsm406_controlpacientes to javafx.fxml;
    exports org.utl.dsm.dsm406_controlpacientes;
    exports org.utl.dsm.dsm406_controlpacientes.controller;
    opens org.utl.dsm.dsm406_controlpacientes.controller to javafx.fxml;
    exports org.utl.dsm.dsm406_controlpacientes.model;
    opens org.utl.dsm.dsm406_controlpacientes.model to com.google.gson;

}
